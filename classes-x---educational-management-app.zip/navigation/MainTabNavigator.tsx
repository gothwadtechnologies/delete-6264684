
import React, { useState } from 'react';
import { User, TabName } from '../types';
import FeesScreen from '../screens/tabs/FeesScreen';
import ClassesScreen from '../screens/tabs/ClassesScreen';
import TestsScreen from '../screens/tabs/TestsScreen';
import AttendanceScreen from '../screens/tabs/AttendanceScreen';
import BatchesScreen from '../screens/tabs/BatchesScreen';

interface MainTabNavigatorProps {
  user: User;
  onOpenDrawer: () => void;
}

const MainTabNavigator: React.FC<MainTabNavigatorProps> = ({ user, onOpenDrawer }) => {
  const [activeTab, setActiveTab] = useState<TabName>('Batches');

  const renderContent = () => {
    switch (activeTab) {
      case 'Batches': return <BatchesScreen user={user} />;
      case 'Classes': return <ClassesScreen user={user} />;
      case 'Tests': return <TestsScreen user={user} />;
      case 'Fees': return <FeesScreen user={user} />;
      case 'Attendance': return <AttendanceScreen user={user} />;
      default: return null;
    }
  };

  const tabs: { name: TabName; icon: string }[] = [
    { name: 'Batches', icon: '📚' },
    { name: 'Classes', icon: '📺' },
    { name: 'Tests', icon: '📝' },
    { name: 'Fees', icon: '💰' },
    { name: 'Attendance', icon: '📅' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="bg-white px-4 py-4 flex items-center justify-between border-b border-gray-100 shrink-0">
        <button onClick={onOpenDrawer} className="p-2 hover:bg-gray-100 rounded-lg">
          <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h2 className="text-xl font-bold text-gray-800 tracking-tight">{activeTab}</h2>
        <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 font-bold border border-blue-100">
          {user.name.charAt(0)}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto bg-gray-50 scroll-hide">
        {renderContent()}
        <div className="py-8 text-center bg-gray-50">
           <p className="text-[10px] tracking-widest text-gray-400 font-black uppercase">
            GOTHWAD TECHNOLOGIES
          </p>
        </div>
      </main>

      {/* Tab Bar */}
      <nav className="bg-white border-t border-gray-100 flex justify-around items-center py-2 px-1 shrink-0 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.name}
            onClick={() => setActiveTab(tab.name)}
            className={`flex flex-col items-center py-2 px-3 transition-all min-w-[60px] ${
              activeTab === tab.name ? 'text-blue-600 scale-105' : 'text-gray-400'
            }`}
          >
            <span className="text-xl mb-1">{tab.icon}</span>
            <span className={`text-[9px] font-bold ${activeTab === tab.name ? 'opacity-100' : 'opacity-60'}`}>
              {tab.name}
            </span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default MainTabNavigator;
