
import React, { useState } from 'react';
import { User, UserRole, Batch, ClassLevel } from '../../types';

const INITIAL_BATCHES: Batch[] = [
  { id: 'b1', name: 'Lakshya NEET 2024', classLevel: '12th', instructor: 'Dr. Alok P.', studentIds: [], thumbnailColor: 'bg-blue-50 border-blue-200', subject: 'Biology' },
  { id: 'b2', name: 'Arjuna JEE Fastrack', classLevel: '11th', instructor: 'Mr. Pankaj S.', studentIds: [], thumbnailColor: 'bg-purple-50 border-purple-200', subject: 'Physics' },
  { id: 'b3', name: 'Udaan Board Special', classLevel: '10th', instructor: 'Ms. Neha R.', studentIds: [], thumbnailColor: 'bg-orange-50 border-orange-200', subject: 'Mathematics' },
  { id: 'b4', name: 'Foundation 9', classLevel: '9th', instructor: 'Mr. Rahul K.', studentIds: [], thumbnailColor: 'bg-green-50 border-green-200', subject: 'Science' },
];

const BatchesScreen: React.FC<{ user: User }> = ({ user }) => {
  const [selectedClass, setSelectedClass] = useState<ClassLevel | 'All'>('All');
  const [batches, setBatches] = useState<Batch[]>(INITIAL_BATCHES);
  const [isAddingBatch, setIsAddingBatch] = useState(false);
  const [newBatchName, setNewBatchName] = useState('');
  const [newBatchClass, setNewBatchClass] = useState<ClassLevel>('10th');

  const isAdmin = user.role === UserRole.ADMIN;
  const classOptions: (ClassLevel | 'All')[] = ['All', '9th', '10th', '11th', '12th'];

  const filteredBatches = selectedClass === 'All' 
    ? batches 
    : batches.filter(b => b.classLevel === selectedClass);

  const handleCreateBatch = () => {
    if (!newBatchName) return;
    const newBatch: Batch = {
      id: `b${Date.now()}`,
      name: newBatchName,
      classLevel: newBatchClass,
      instructor: user.name,
      studentIds: [],
      thumbnailColor: 'bg-indigo-50 border-indigo-200',
      subject: 'General'
    };
    setBatches([newBatch, ...batches]);
    setNewBatchName('');
    setIsAddingBatch(false);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Search & Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2 scroll-hide">
        {classOptions.map(opt => (
          <button
            key={opt}
            onClick={() => setSelectedClass(opt)}
            className={`px-5 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap shadow-sm border ${
              selectedClass === opt 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-500 border-gray-100 hover:bg-gray-50'
            }`}
          >
            {opt === 'All' ? 'All Classes' : opt}
          </button>
        ))}
      </div>

      {/* Admin Quick Action */}
      {isAdmin && !isAddingBatch && (
        <button 
          onClick={() => setIsAddingBatch(true)}
          className="w-full bg-blue-50 border-2 border-dashed border-blue-200 p-4 rounded-2xl flex items-center justify-center gap-2 text-blue-600 font-bold active:scale-[0.98] transition-all"
        >
          <span>➕</span> Create New Batch
        </button>
      )}

      {/* Create Batch Modal/Form */}
      {isAddingBatch && (
        <div className="bg-white p-5 rounded-2xl shadow-xl border border-blue-100 animate-in fade-in zoom-in duration-200">
          <h3 className="font-bold text-gray-900 mb-4">Create New Batch</h3>
          <div className="space-y-3">
            <input 
              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 font-medium" 
              placeholder="Batch Name (e.g. Lakshya 2025)"
              value={newBatchName}
              onChange={(e) => setNewBatchName(e.target.value)}
            />
            <select 
              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 font-medium"
              value={newBatchClass}
              onChange={(e) => setNewBatchClass(e.target.value as ClassLevel)}
            >
              <option value="9th">Class 9th</option>
              <option value="10th">Class 10th</option>
              <option value="11th">Class 11th</option>
              <option value="12th">Class 12th</option>
            </select>
            <div className="flex gap-2 pt-2">
              <button 
                onClick={handleCreateBatch}
                className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-100"
              >
                Save Batch
              </button>
              <button 
                onClick={() => setIsAddingBatch(false)}
                className="flex-1 bg-gray-100 text-gray-600 font-bold py-3 rounded-xl"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batches List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredBatches.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-2 opacity-20">📂</div>
            <p className="text-gray-400 font-medium">No batches found for {selectedClass}</p>
          </div>
        ) : (
          filteredBatches.map(batch => (
            <div key={batch.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 group">
              {/* Updated Header with Black Text */}
              <div className={`h-24 ${batch.thumbnailColor} border-b p-4 flex flex-col justify-end relative`}>
                <div className="absolute top-4 right-4 bg-white/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-black uppercase text-gray-900 border border-white/20">
                  {batch.classLevel}
                </div>
                <h4 className="text-lg font-black leading-tight text-gray-900">{batch.name}</h4>
              </div>
              <div className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{batch.subject}</p>
                  <p className="text-sm font-bold text-gray-900">{batch.instructor}</p>
                </div>
                <button className="bg-gray-900 text-white text-[10px] font-black px-4 py-2 rounded-lg uppercase tracking-tighter active:scale-95 transition-all">
                  {isAdmin ? 'Manage' : 'Explore'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Updated Hero Card with Black Text */}
      <div className="mt-8 bg-blue-50 border border-blue-100 rounded-3xl p-6 overflow-hidden relative shadow-sm">
        <div className="relative z-10">
          <h3 className="text-xl font-black mb-1 text-gray-900">Scholarship Test 2024</h3>
          <p className="text-gray-600 text-xs mb-4 font-medium">Up to 100% scholarship for top performers.</p>
          <button className="bg-blue-600 text-white font-black py-2.5 px-6 rounded-xl text-xs uppercase tracking-tighter shadow-lg shadow-blue-200 active:scale-95 transition-all">
            Apply Now
          </button>
        </div>
        <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-blue-100/50 rounded-full blur-3xl"></div>
        <div className="absolute top-0 right-0 p-4 opacity-10 text-blue-600">
          <svg className="w-20 h-20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
        </div>
      </div>
    </div>
  );
};

export default BatchesScreen;
