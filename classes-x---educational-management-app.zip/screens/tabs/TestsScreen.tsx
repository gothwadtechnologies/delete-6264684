
import React from 'react';
import { User, Test } from '../../types';

const MOCK_TESTS: Test[] = [
  { id: '1', title: 'Unit Test 1 - Calculus', date: 'Oct 20, 2023', score: 85, totalMarks: 100 },
  { id: '2', title: 'Midterm Exam - Physics', date: 'Nov 05, 2023', score: 42, totalMarks: 50 },
  { id: '3', title: 'Biology Quiz', date: 'Dec 01, 2023', totalMarks: 25 },
];

const TestsScreen: React.FC<{ user: User }> = () => {
  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center px-1 mb-2">
        <h3 className="text-sm font-bold text-gray-800">Academic History</h3>
        <button className="text-blue-600 text-xs font-bold">View Stats</button>
      </div>

      <div className="space-y-3">
        {MOCK_TESTS.map(test => (
          <div key={test.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex flex-col items-center justify-center">
                 <span className="text-xs font-bold leading-none">{test.id}</span>
                 <span className="text-[8px] uppercase font-black opacity-50">Test</span>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 text-sm">{test.title}</h4>
                <p className="text-[10px] text-gray-400 font-medium">{test.date}</p>
              </div>
            </div>
            <div className="text-right">
              {test.score !== undefined ? (
                <div className="flex flex-col items-end">
                  <p className="text-lg font-black text-blue-600 leading-none">{test.score}</p>
                  <p className="text-[10px] text-gray-400 font-bold">/{test.totalMarks}</p>
                </div>
              ) : (
                <span className="bg-yellow-50 text-yellow-600 px-2 py-1 rounded text-[10px] font-bold uppercase">Pending</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Updated Weekly Mock Test Card with Black Text */}
      <div className="mt-8 p-6 bg-gray-50 border border-gray-100 rounded-3xl text-gray-900 relative overflow-hidden shadow-sm">
        <div className="relative z-10">
          <h4 className="text-xl font-black mb-1">Weekly Mock Test</h4>
          <p className="text-gray-500 text-xs mb-4 font-medium">Prepare yourself with live mock exams every Sunday.</p>
          <button className="bg-blue-600 text-white font-bold py-2 px-6 rounded-xl text-xs active:scale-95 transition-all shadow-lg shadow-blue-100">Register Now</button>
        </div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-100/30 rounded-full blur-2xl"></div>
      </div>
    </div>
  );
};

export default TestsScreen;
