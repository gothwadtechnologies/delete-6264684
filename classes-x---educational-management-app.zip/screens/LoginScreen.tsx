
import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface LoginScreenProps {
  role: UserRole;
  onLogin: (user: User) => void;
  onBack: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ role, onLogin, onBack }) => {
  const [identifier, setIdentifier] = useState(''); // Email for Admin, Registration Number for Student/Parent
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const isAdmin = role === UserRole.ADMIN;

  useEffect(() => {
    const savedIdentifier = localStorage.getItem(`remembered_id_${role}`);
    if (savedIdentifier) {
      setIdentifier(savedIdentifier);
      setRememberMe(true);
    }
  }, [role]);

  const handleDemoLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      const demoUser: User = {
        uid: 'demo-uid',
        name: `Demo ${role === UserRole.ADMIN ? 'Admin' : role === UserRole.STUDENT ? 'Student' : 'Parent'}`,
        role: role,
        phone: '0000000000',
        email: 'demo@classesx.com'
      };
      onLogin(demoUser);
      setIsLoading(false);
    }, 1000);
  };

  const handleLoginAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      let loginEmail = identifier.trim();
      if (role === UserRole.STUDENT) {
        loginEmail = `${identifier.trim().toLowerCase()}@student.classesx.com`;
      } else if (role === UserRole.PARENT) {
        loginEmail = `${identifier.trim().toLowerCase()}@parent.classesx.com`;
      }

      const userCredential = await signInWithEmailAndPassword(auth, loginEmail, password);
      const fbUser = userCredential.user;

      const userDocRef = doc(db, "users", fbUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      let userData: User;

      if (userDoc.exists()) {
        const data = userDoc.data();
        if (data.role && data.role !== role) {
          await auth.signOut();
          throw new Error(`This account is not registered as a ${role.toLowerCase()}.`);
        }

        userData = {
          uid: fbUser.uid,
          name: data.name || (isAdmin ? "Admin User" : "Learner"),
          role: data.role as UserRole,
          phone: data.phone || identifier,
          email: fbUser.email || undefined
        };
      } else {
        const initialProfile = {
          name: isAdmin ? "System Administrator" : `User ${identifier}`,
          role: role,
          phone: isAdmin ? "" : identifier,
          createdAt: new Date().toISOString()
        };
        await setDoc(userDocRef, initialProfile);
        
        userData = {
          uid: fbUser.uid,
          ...initialProfile,
          email: fbUser.email || undefined
        };
      }

      if (rememberMe) {
        localStorage.setItem(`remembered_id_${role}`, identifier);
      } else {
        localStorage.removeItem(`remembered_id_${role}`);
      }

      onLogin(userData);

    } catch (err: any) {
      console.error("Login Error:", err);
      let message = "Invalid email or password. Please try again.";
      
      // Specifically handle the new Firebase auth/invalid-credential error
      if (err.code === 'auth/invalid-credential') {
        message = "Incorrect registration details. Check your ID and password.";
      } else if (err.code === 'auth/user-not-found') {
        message = "No account found with these details.";
      } else if (err.code === 'auth/wrong-password') {
        message = "The password you entered is incorrect.";
      } else if (err.code === 'auth/invalid-email') {
        message = "The format of the ID/Email is incorrect.";
      }
      
      setError(err.message || message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-white p-8 flex flex-col overflow-y-auto scroll-hide">
      <div className="mt-4 shrink-0">
        <button 
          onClick={onBack} 
          className="flex items-center gap-1 text-gray-400 hover:text-blue-600 font-medium text-sm transition-colors group"
        >
          <svg className="w-4 h-4 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to selection
        </button>
      </div>

      <div className="mt-8 mb-10 flex flex-col items-center shrink-0">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg mb-3">
          <span className="text-white text-2xl font-black italic">X</span>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 tracking-tight text-center">
          {isAdmin ? 'Admin Portal' : `${role === UserRole.STUDENT ? 'Student' : 'Parent'} Login`}
        </h2>
        <p className="text-gray-400 text-sm mt-1">Access your educational dashboard</p>
      </div>

      <form onSubmit={handleLoginAction} className="space-y-4 flex-1">
        {error && (
          <div className="bg-red-600 text-white p-4 rounded-2xl text-[11px] font-bold shadow-lg shadow-red-100 mb-4 flex flex-col gap-2 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-1.5 rounded-lg shrink-0">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <p className="flex-1 leading-tight">{error}</p>
            </div>
            <button 
              type="button"
              onClick={handleDemoLogin}
              className="mt-1 bg-white text-red-600 px-3 py-1.5 rounded-lg text-[10px] uppercase font-black self-end"
            >
              Skip to Demo Mode
            </button>
          </div>
        )}
        
        <div>
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1 mb-1.5">
            {isAdmin ? 'Official Email Address' : 'Registration Number'}
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300">
              {isAdmin ? '📧' : '🆔'}
            </span>
            <input 
              type={isAdmin ? "email" : "text"}
              required
              className="w-full pl-11 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all shadow-sm text-gray-900 font-medium"
              placeholder={isAdmin ? "admin@classesx.com" : "e.g. 2024-ST-001"}
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1 mb-1.5">Secret Password</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300">
              {isAdmin ? '🛡️' : '🔑'}
            </span>
            <input 
              type={showPassword ? "text" : "password"}
              required
              className="w-full pl-11 pr-12 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all shadow-sm text-gray-900 font-medium"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-blue-600 transition-colors focus:outline-none"
            >
              {showPassword ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              )}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between px-1">
          <label className="flex items-center gap-2 cursor-pointer group">
            <div className="relative flex items-center">
              <input 
                type="checkbox" 
                className="peer h-5 w-5 cursor-pointer appearance-none rounded border border-gray-200 transition-all checked:bg-blue-600 checked:border-blue-600"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <span className="absolute text-white opacity-0 peer-checked:opacity-100 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor" stroke="currentColor" strokeWidth="1">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                </svg>
              </span>
            </div>
            <span className="text-xs font-bold text-gray-500 group-hover:text-blue-600 transition-colors">Remember Me</span>
          </label>
          
          <button type="button" className="text-[10px] font-bold text-blue-600 hover:underline">Forgot Password?</button>
        </div>

        <button 
          disabled={isLoading}
          type="submit"
          className={`w-full bg-blue-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-4 ${isLoading ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700 shadow-blue-200'}`}
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              Sign In
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </>
          )}
        </button>
      </form>

      <div className="mt-8 text-center shrink-0">
        <button 
          onClick={handleDemoLogin}
          className="text-gray-400 text-xs font-medium hover:text-blue-600 transition-colors"
        >
          Use Demo Access? <span className="text-blue-600 font-bold underline">Try Classes X</span>
        </button>
      </div>

      <div className="mt-auto pt-8 flex flex-col items-center gap-2 shrink-0">
        <p className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">
          GOTHWAD TECHNOLOGIES
        </p>
        <div className="h-px w-full bg-gray-50 mb-2" />
        <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest opacity-40">
          SECURE ENCRYPTED CHANNEL
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;
